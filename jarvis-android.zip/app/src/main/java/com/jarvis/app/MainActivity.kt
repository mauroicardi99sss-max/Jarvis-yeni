package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var rec: SpeechRecognizer? = null
    private var listening = false
    private val ui = Handler(Looper.getMainLooper())

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript("window.$code", null) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.setBackgroundColor(0xFF020A12.toInt())
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) = js("onTalk(true)")
                    override fun onDone(id: String?) = js("onTalk(false)")
                    override fun onError(id: String?) = js("onTalk(false)")
                })
            }
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    private fun nextListen() {
        if (!listening) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        try { rec?.startListening(i) } catch (e: Exception) { ui.postDelayed({ nextListen() }, 800) }
    }

    private fun startRec() {
        if (rec == null) {
            rec = SpeechRecognizer.createSpeechRecognizer(this)
            rec?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        ?.let { js("onHeard(${JSONObject.quote(it)})") }
                    ui.postDelayed({ nextListen() }, 200)
                }
                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { listening = false; return }
                    ui.postDelayed({ nextListen() }, 600)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        listening = true
        nextListen()
    }

    private fun stopRec() { listening = false; rec?.cancel() }

    inner class Bridge {
        @JavascriptInterface fun speak(t: String) { runOnUiThread { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j") } }
        @JavascriptInterface fun listen(on: Boolean) { runOnUiThread { if (on) startRec() else stopRec() } }
    }

    override fun onPause() {
        super.onPause()
        if (listening) {
            stopRec()
            js("document.querySelector('#mic').click()")
        }
    }

    override fun onDestroy() {
        rec?.destroy(); tts?.shutdown()
        super.onDestroy()
    }
}
